For my website, I used a variety of techniques from different sources:

1.) I learned how to create a navbar from the YouTube video 'Navbar CSS Tutorial: 3 Ways to Create a Navigation Bar with Flexbox' by Skillthrive:
https://www.youtube.com/watch?v=PwWHL3RyQgk

2.) I learned how to create the FAQ accordion dropdown from the YouTube video 'Responsive FAQ accordion dropdown | HTML and CSS Tutorial' by Julio Codes:
https://www.youtube.com/watch?v=MXrtXg1kpVs

3.) I learned how to create my star rating system from the YouTube video 'Star Rating System in HTML CSS & JavaScript | CodingNepal' by CodingNepal:
https://www.youtube.com/watch?v=rw3eZ6XodN8

4.) My responsive gallery image was created by the YouTube video 'How to create Responsive Image Gallery Layout using CSS display Grid | HTML and CSS Tutorial' by KODAKTIF VIDEO EGITIM:
https://www.youtube.com/watch?v=TuBwe6SLRlU

5.) I learned how to create a contact form with javascript from the YouTube video 'AWESOME Contact Form Using HTML, CSS, and JavaScript' by CodeBrah:
https://www.youtube.com/watch?v=QT1ya4Ut40o
The contact form has an 'onsubmit' tag in the html that was supposed to be removed, but I had to input it to work

6.) I added my favicon by learning from the YouTube video 'Add A Favicon to A Website in HTML | Learn HTML and CSS | HTML Tutorial | HTML for Beginners' by Dani Krossing:
https://www.youtube.com/watch?v=kEf1xSwX5D8

7.) I learned how to add my customer review section from the YouTube video 'Responsive Customer Reviews on Website Only Using HTML and CSS' by Going-To Internet:
https://www.youtube.com/watch?v=O-QUBZuZlXM
